# Documento de Diseño del Videojuego (GDD)

**Nombre provisional:** EcoGuardianes: La Aventura del Agua y la Fauna

1. **Género.** Educativo, con estructura de aventura/exploración y minijuegos organizados por niveles.
2. **Público objetivo.** Niños de 7 a 14 años, con acompañamiento opcional de docentes o acudientes.
3. **Objetivo de aprendizaje.** Comprender el cuidado del agua y la protección de la fauna silvestre (ODS 6 y 15) y traducirlo en decisiones concretas dentro del juego.
4. **Narrativa.** El jugador es un joven explorador que descubre que los ecosistemas de su región (río, humedal, bosque) pierden el equilibrio por el mal uso del agua y las amenazas a la fauna. Guiado por **Runa**, una nutria, restaura cada ecosistema hasta convertirse en "Guardián del Agua y la Fauna".
5. **Personajes.**
   - Guías: el niño explorador (avatar) y Runa, la nutria.
   - Fauna silvestre (aliados a rescatar): peces, aves, anfibios, mamíferos.
   - Amenazas del entorno: contaminación, desperdicio de agua, deforestación — **obstáculos a resolver, no enemigos a atacar**.
6. **Estilo visual y sonoro.** Pixel art 2D top-down, colores vivos, escenarios inspirados en paisajes colombianos. Música alegre, efectos ambientales y mensajes cortos de voz de Runa.
7. **Mecánicas.** Cálculo simple de consumo energético · recolección de objetos (residuos, gotas) · resolución de retos · recompensas (puntos, insignias, zonas desbloqueables) · niveles cortos con dificultad progresiva.

## Niveles

| # | Nombre | Enfoque | Tarjeta del Guardián |
| --- | --- | --- | --- |
| 1 | El río en peligro | Ahorro y descontaminación del agua (máx. 3 min) | Art. 366 |
| 2 | El humedal olvidado | Hábitat de la fauna acuática; Asamblea del humedal | Art. 8 |
| 3 | El bosque silencioso | Fauna silvestre amenazada | Art. 80 |
| 4 | La escuela sostenible | Consumo de energía de electrodomésticos | Art. 95 num. 8 |
| 5 | El Refugio de la Vida | Escena final con ecosistemas restaurados | Art. 79 |

## Interfaz

- **Menú principal:** Jugar, Insignias, Configuración (+ acceso discreto al panel docente con PIN).
- **Partida:** barra de progreso, contador de gotas/estrellas, ícono de Runa, ícono del ODS.
- **Recompensa:** animación de celebración, insignia, puntaje, Tarjeta del Guardián y compromiso del guardián.

## Reglas del videojuego

- Identificar el electrodoméstico de mayor consumo y apagarlo o reemplazarlo → puntos adicionales y baja el "medidor de energía".
- Recoger un residuo o ahorrar agua → **10 puntos**.
- Decisión que perjudica al ecosistema → retroalimentación inmediata y reintento (hasta 3 intentos por reto antes de ofrecer una pista).
- Completar los retos de un nivel → desbloquea el siguiente y otorga una insignia.
- Acumular las 4 insignias → desbloquea el nivel final.

## Duración

Nivel 1: máximo 3 minutos. Recorrido completo: aproximadamente 20 a 25 minutos.

## Pedagogía

Aprendizaje por retos, refuerzo positivo (insignias), progreso visible y transversalidad con los ODS. Lenguaje sin tono de obligación.

## Ciclo del sistema

**Entrada** (decisión por teclado, mouse o táctil) → **Procesamiento** (reglas, puntaje, estado del ecosistema) → **Salida** (puntaje, mensaje de Runa, recompensas) → **Retroalimentación** (el jugador ajusta su siguiente decisión).

## Tecnologías

Unity 6 LTS (2D) + C# · SQLite 3 · LibreSprite · Audacity · Git y GitHub.
