# Diagramas y prototipos

Coloca aquí las imágenes exportadas del documento del avance (PNG o SVG), con estos nombres:

| Archivo sugerido | Contenido | Sección del documento |
| --- | --- | --- |
| `fig1-contexto.png` | Diagrama de contexto del sistema | 6.1 |
| `fig2-casos-de-uso.png` | Diagrama de casos de uso | 6.3 |
| `fig3-flujo-ciclo-juego.png` | Diagrama de flujo del ciclo de juego | 6.3 |
| `fig4-arquitectura.png` | Arquitectura por capas | 6.5 |
| `fig5-entidad-relacion.png` | Modelo entidad–relación | 6.5 |
| `../prototipos/fig6-wireframes.png` | Wireframes: menú, nivel 1, reto nivel 4, recompensa | 10 |

Para extraerlas del `.docx`: renombra el archivo a `.zip` y copia las imágenes de la carpeta `word/media/`.

Cuando estén los archivos, enlázalos desde el `README.md` principal con `![Contexto](docs/diagramas/fig1-contexto.png)`.
