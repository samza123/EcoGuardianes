# Requerimientos del sistema — EcoGuardianes

Fuente: *Segundo avance P.I — Sistemas* (secciones 5.2 y 6.4). Prioridad: **A** = Alta, **M** = Media, **B** = Baja.

## Requerimientos funcionales

### Estructura de Datos

| ID | Requerimiento | Prior. | Verificación |
| --- | --- | --- | --- |
| RF-EST-01 | Residuos y gotas recolectados en una lista dinámica (agregar, eliminar, consultar) | A | Pruebas unitarias con 0, 1 y 100 elementos |
| RF-EST-02 | Decisiones del jugador en una pila (LIFO); al reintentar se deshace la última y se restaura el ecosistema | A | Tras N decisiones y un reintento, el estado es idéntico al previo a la última decisión |
| RF-EST-03 | Retos pendientes del nivel en una cola (FIFO); los fallados se reinsertan al final | M | Nivel de 5 retos: orden de aparición = orden esperado |
| RF-EST-04 | Mapa de niveles como grafo dirigido; el nivel final requiere las 4 insignias | A | Nivel 5 bloqueado con 3 insignias, desbloqueado con 4 |
| RF-EST-05 | Insignias, especies y electrodomésticos en tablas hash con ID único | M | Revisión de código + consulta por ID con 1000 registros |
| RF-EST-06 | Ordenar electrodomésticos del nivel 4 de mayor a menor consumo con algoritmo propio (QuickSort o MergeSort) | M | Listas ordenadas, inversas y con valores repetidos |
| RF-EST-07 | Cada estructura encapsulada en una clase propia, con complejidad Big-O documentada | M | Revisión documental (100 %) |

### Matemáticas 3

| ID | Requerimiento | Prior. | Verificación |
| --- | --- | --- | --- |
| RF-MAT-01 | Concentración de contaminantes C(x, y) en malla ≥ 50×50 como mapa de calor | A | C(x, y) en 5 puntos = cálculo manual |
| RF-MAT-02 | Gradiente ∇C en la posición del jugador, mostrado como flecha | A | Error relativo ≤ 1 % en 3 funciones de prueba |
| RF-MAT-03 | Cantidad total de contaminante en región rectangular (integral doble numérica, suma de Riemann) y % retirado | A | Error relativo ≤ 1 % en 3 funciones de prueba |
| RF-MAT-04 | Corriente del río como campo vectorial F(x, y) que desplaza residuos | M | Posición tras 10 s dentro de tolerancia del 2 % |
| RF-MAT-05 | "Modo Guardián Científico" (solo docente/acudiente) con procedimiento paso a paso | M | Cada cálculo muestra ≥ 3 pasos |
| RF-MAT-06 | Gráfica 3D de la superficie C(x, y) dentro del modo anterior | B | Forma coincide con la función |

### Física 2

| ID | Requerimiento | Prior. | Verificación |
| --- | --- | --- | --- |
| RF-FIS-01 | Nivel 4: mostrar potencia (W) y tiempo diario (h); calcular E = P × t en kWh con 2 decimales | A | Plancha 1000 W × 2 h = 2,00 kWh |
| RF-FIS-02 | Consumo mensual (30 días) y costo con tarifa por kWh configurable | M | 1000 W, 2 h/día, 30 días = 60 kWh |
| RF-FIS-03 | Comparar dos electrodomésticos: diferencia en kWh y % | A | Coincide con cálculo manual |
| RF-FIS-04 | Mostrar unidades (W, kW, J, kWh) y alternar kWh ↔ J (1 kWh = 3,6 × 10⁶ J) | M | 5 casos de conversión |
| RF-FIS-05 | Procedimiento paso a paso de cada cálculo, con lenguaje para 7–14 años | A | 100 % de cálculos del nivel 4 con 3 pasos |
| RF-FIS-06 | Volumen de agua V = Q × t y ahorro al reducir tiempo | M | Q = 10 L/min, t = 5 min → 50 L |

### Sistemas de Información

| ID | Requerimiento | Prior. | Verificación |
| --- | --- | --- | --- |
| RF-SIS-01 | Menú principal con Jugar, Insignias y Configuración | A | Aparece en ≤ 5 s |
| RF-SIS-02 | Perfiles identificados solo con alias; varios perfiles por equipo | A | 3 perfiles con progreso independiente |
| RF-SIS-03 | Ciclo entrada–procesamiento–salida–retroalimentación con mensaje de Runa | A | Retroalimentación ≤ 1 s en 100 % de acciones |
| RF-SIS-04 | 10 puntos por residuo/agua ahorrada; insignia al completar nivel; desbloqueo del siguiente | A | Simulación de partida completa |
| RF-SIS-05 | Guardado automático en BD local al completar nivel y al cerrar | A | Cerrar/reabrir: progreso idéntico |
| RF-SIS-06 | Registro por reto: nivel, resultado, intentos, tiempo | M | 5 registros tras un nivel de 5 retos |
| RF-SIS-07 | Panel docente con PIN de 4 dígitos | M | Sin PIN no hay acceso; con PIN se ven 4 datos |
| RF-SIS-08 | Exportar reporte del panel a CSV | B | Abre en Excel con mismas columnas |

### Electiva Libre III

| ID | Requerimiento | Prior. | Verificación |
| --- | --- | --- | --- |
| RF-ELE-01 | Cuestionario de 6 preguntas (3 conocimiento, 3 actitud) al inicio y final | A | Ambos se guardan; el panel muestra la diferencia |
| RF-ELE-02 | Álbum de fauna: ficha por especie rescatada (nombre, hábitat, amenaza, acción) | A | 4 campos completos por especie |
| RF-ELE-03 | Ícono del ODS (6 o 15) al iniciar nivel y en recompensa | M | 100 % de niveles |
| RF-ELE-04 | "Compromiso del guardián" al final de cada nivel, registrado en el panel | M | Compromisos aceptados visibles en panel |
| RF-ELE-05 | Animación y mensaje de Runa al rescatar un animal | A | 100 % de especies |
| RF-ELE-06 | Glosario ilustrado (cuenca, humedal, biodiversidad, consumo, energía), definiciones ≤ 20 palabras | B | Ilustración + definición dentro del límite |

### Constitución Política

| ID | Requerimiento | Prior. | Verificación |
| --- | --- | --- | --- |
| RF-CON-01 | "Tarjeta del Guardián" por nivel: N1 Art. 366, N2 Art. 8, N3 Art. 80, N4 Art. 95 num. 8, N5 Art. 79 | A | 5 tarjetas; texto verificado contra el texto oficial |
| RF-CON-02 | "Asamblea del humedal" (nivel 2): votar entre 3 propuestas, efecto visible | M | 3 propuestas con efectos distintos |
| RF-CON-03 | Sección "Derechos y deberes" en Insignias con tarjetas desbloqueadas | B | Bloqueadas/desbloqueadas correctas |
| RF-CON-04 | Aviso de tratamiento de datos y aceptación antes de guardar datos adicionales al alias (Ley 1581 de 2012) | A | Sin aceptación no se guarda nada |
| RF-CON-05 | Accesibilidad: subtítulos, alto contraste, 3 tamaños de letra | A | 3 opciones funcionan y persisten |

## Requerimientos no funcionales

| ID | Categoría | Requerimiento |
| --- | --- | --- |
| RNF-01 | Usabilidad | ≥ 90 % de ≥ 5 niños (7–14 años) completa el nivel 1 sin ayuda |
| RNF-02 | Usabilidad | Español, mensajes ≤ 20 palabras, letra ≥ 16 pt, sin "debes"/"tienes que" |
| RNF-03 | Usabilidad | Nivel 1 ≤ 3 min; recorrido completo entre 20 y 25 min |
| RNF-04 | Rendimiento | Retroalimentación ≤ 1 s, carga de nivel ≤ 5 s, ≥ 30 FPS en el 95 % del tiempo |
| RNF-05 | Rendimiento | Gradiente e integral doble en malla 100×100 en ≤ 500 ms |
| RNF-06 | Portabilidad | Windows 10+, ≤ 500 MB, teclado/mouse/táctil, 1366×768 a 1920×1080 |
| RNF-07 | Confiabilidad | Sin cierres en 95 % de sesiones de 30 min; pérdida máxima = nivel en curso |
| RNF-08 | Confiabilidad | Error relativo ≤ 1 % en módulos de Matemáticas 3 y Física 2 |
| RNF-09 | Seguridad | Solo alias y progreso; sin publicidad, chat ni enlaces externos; panel con PIN |
| RNF-10 | Mantenibilidad | Contenido en archivos de configuración externos, sin recompilar |
| RNF-11 | Mantenibilidad | Convenciones de nomenclatura, módulos por nivel, comentarios, control de versiones |
| RNF-12 | Escalabilidad | Agregar un nivel = registrar un nodo en el grafo, sin tocar niveles existentes |
| RNF-13 | Accesibilidad | Contraste ≥ 4,5:1; nada depende solo del color |
| RNF-14 | Ética y contenido | Sin violencia, animales heridos/muertos, alarmas atemorizantes ni discriminación |
| RNF-15 | Trazabilidad | Cada requerimiento con ID y origen; diagramas actualizados al 100 % |

## Trazabilidad

| Asignatura | Componente | Requerimientos | Objetivos específicos |
| --- | --- | --- | --- |
| Estructura de Datos | Motor interno | RF-EST-01 a 07 | OE-1, OE-4 |
| Matemáticas 3 | Niveles 1 y 2 | RF-MAT-01 a 06 | OE-1, OE-3 |
| Física 2 | Nivel 4 | RF-FIS-01 a 06 | OE-6 |
| Sistemas de Información | Núcleo, progreso, panel docente | RF-SIS-01 a 08 | OE-1, OE-4 |
| Electiva Libre 3 | Contenido ambiental, álbum, evaluación | RF-ELE-01 a 06 | OE-2, OE-5 |
| Constitución Política | Tarjetas, asamblea, datos, accesibilidad | RF-CON-01 a 05 | OE-3 |
