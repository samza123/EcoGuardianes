# Arquitectura y modelo de datos

## Arquitectura por capas

Cada capa solo depende de las inferiores.

```
┌───────────────────────────────────────────────┐
│ Presentación (Unity UI)                       │ menú, partida, recompensa, panel docente, configuración
├───────────────────────────────────────────────┤
│ Lógica de juego                               │ reglas, puntaje, estado del ecosistema, grafo de niveles
│   └─ módulos por nivel (nodos del grafo)      │
├───────────────────────────────────────────────┤
│ Módulos de cálculo + estructuras de datos     │ Matemáticas 3, Física 2, lista/pila/cola/grafo/hash/sort
├───────────────────────────────────────────────┤
│ Persistencia (SQLite)  │ Configuración (JSON) │ datos del jugador │ contenido editable
└───────────────────────────────────────────────┘
```

Correspondencia con carpetas: `UI/` → presentación · `Core/` y `Levels/` → lógica · `Math/`, `Physics/`, `DataStructures/` → cálculo y estructuras · `Persistence/` y `Data/Config/` → datos.

## Modelo de datos (SQLite local)

Solo se guarda lo necesario para continuar la partida y reportar avance (RNF-09). Entidades:

- Perfil (solo alias)
- Progreso
- Registro de reto (nivel, resultado, intentos, tiempo)
- Insignias ganadas
- Fichas del álbum de fauna
- Cuestionarios inicial y final
- Compromisos aceptados
- Ajustes de accesibilidad

**No** se guardan en la BD: catálogos de preguntas, especies, tarjetas, electrodomésticos y tarifa (van en JSON). El **PIN** del panel docente se guarda como hash en la configuración del equipo, no en los perfiles.

El diagrama entidad–relación completo está en la Figura 5 del documento del avance (ver `diagramas/README.md`).

## Estructuras de datos y complejidad

> Complejidades estándar de cada estructura; confirmar contra la implementación final (RF-EST-07).

| Estructura | Uso | Requerimiento | Operaciones (caso típico) |
| --- | --- | --- | --- |
| Lista dinámica | Residuos y gotas recolectados | RF-EST-01 | Agregar O(1) amortizado · consultar por índice O(1) · eliminar O(n) |
| Pila (LIFO) | Historial de decisiones / deshacer | RF-EST-02 | Push y Pop O(1) |
| Cola (FIFO) | Retos pendientes | RF-EST-03 | Enqueue y Dequeue O(1) |
| Grafo dirigido | Mapa de niveles | RF-EST-04 | Agregar nodo/arista O(1) · consultar prerrequisitos O(grado) |
| Tabla hash | Insignias, especies, electrodomésticos | RF-EST-05 | Buscar/insertar O(1) promedio |
| MergeSort | Ordenar electrodomésticos por consumo | RF-EST-06 | O(n log n) |

## Escalabilidad (RNF-12)

Cada nivel es un módulo independiente registrado como nodo del grafo; agregar un nivel no modifica el código de los existentes.
