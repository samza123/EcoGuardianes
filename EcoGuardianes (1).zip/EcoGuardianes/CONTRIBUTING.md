# Guía de contribución

Proyecto desarrollado con **Scrum** sobre un **modelo incremental** (sprints de 2 semanas). El Product Backlog vive en **GitHub Projects**.

## Primer commit con Unity (solo una vez, lo hace una persona)

El repositorio inicial trae carpetas, scripts y documentación, pero no los archivos que Unity genera al crear un proyecto.

1. En Unity Hub crea un proyecto **2D (Universal 2D)** con Unity 6 LTS **dentro de una carpeta temporal**.
2. Copia a la raíz del repositorio las carpetas `ProjectSettings/` y `Packages/` generadas.
3. Copia también el contenido de `Assets/` que Unity haya creado (por ejemplo `Scenes/`) dentro de `Assets/_Project/` si corresponde.
4. Abre la raíz del repositorio como proyecto en Unity y deja que genere los `.meta`.
5. **Commitea los archivos `.meta`** (son necesarios; no están en `.gitignore`).
6. En Unity: *Edit → Project Settings → Editor → Asset Serialization → Force Text* y *Version Control → Visible Meta Files*. (Verifica los nombres exactos en tu versión del editor.)

## Flujo de ramas

| Rama | Uso |
| --- | --- |
| `main` | Siempre estable; solo recibe merges al cerrar un incremento |
| `develop` | Integración continua del equipo |
| `feature/<id>-<descripcion>` | Un requerimiento o tarea (ej. `feature/RF-EST-02-pila-decisiones`) |
| `fix/<descripcion>` | Corrección de errores |

```bash
git checkout develop
git pull
git checkout -b feature/RF-EST-02-pila-decisiones
# ... trabajo ...
git add .
git commit -m "feat(RF-EST-02): pila de decisiones con deshacer"
git push -u origin feature/RF-EST-02-pila-decisiones
# abrir Pull Request hacia develop
```

## Mensajes de commit

Formato: `tipo(ID): descripción corta`

Tipos: `feat`, `fix`, `docs`, `test`, `refactor`, `chore`.
Usa el **ID del requerimiento** cuando aplique (trazabilidad, RNF-15).

## Definition of Done

Un elemento se considera terminado cuando:

- [ ] Tiene identificador de requerimiento
- [ ] Cumple su criterio de verificación (ver `docs/REQUERIMIENTOS.md`)
- [ ] Tuvo revisión cruzada (otro integrante aprobó el Pull Request)
- [ ] Tiene trazabilidad con su objetivo específico

## Convenciones de código (RNF-11)

- C# con convenciones del lenguaje: `PascalCase` para clases y métodos públicos, `camelCase` para variables locales, `_camelCase` para campos privados.
- Un módulo por nivel dentro de `Scripts/Levels/`.
- Comentarios en los métodos públicos.
- Textos, puntajes, potencias, tarifa, especies y tarjetas van en `Assets/_Project/Data/Config/` (JSON), **no en el código** (RNF-10).

## Reglas de contenido (RNF-09, RNF-14)

- Sin publicidad, chat ni enlaces externos.
- Sin violencia ni animales heridos o muertos.
- Textos de máximo 20 palabras, sin "debes" ni "tienes que".
- Solo se almacena alias y progreso del jugador.

## Archivos grandes

Evita subir fuentes pesadas (`.psd`, audio sin comprimir). Si el equipo decide usar Git LFS, descomenta las reglas en `.gitattributes` y que **todos** instalen LFS antes.
