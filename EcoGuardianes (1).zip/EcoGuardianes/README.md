# 🌊 EcoGuardianes: La Aventura del Agua y la Fauna

Videojuego educativo 2D (pixel art, vista top-down) para promover el **cuidado del agua**, la **protección de la fauna silvestre** y el **ahorro de energía eléctrica** en niños de **7 a 14 años**, en el marco de los **ODS 6** (Agua limpia y saneamiento) y **15** (Vida de ecosistemas terrestres).

> Proyecto integrador — Ingeniería de Sistemas, Facultad de Ingeniería, **UCEVA** (Tuluá, Valle del Cauca). Periodo académico 2026-2. Asignatura: Sistemas de Información (docente: Mary Luz Ojeda Solarte).

## Estado del proyecto

| Incremento | Contenido | Estado |
| --- | --- | --- |
| 1 | Análisis y diseño (requerimientos, GDD, diagramas, prototipos) | ✅ Documentado en el avance de Sistemas de Información |
| 2 | Núcleo del sistema + Nivel 1 | ⏳ Pendiente |
| 3 | Niveles 2 y 3 | ⏳ Pendiente |
| 4 | Nivel 4 y panel docente | ⏳ Pendiente |
| 5 | Nivel final y pruebas integrales | ⏳ Pendiente |

## Resumen del juego

El jugador es un joven explorador guiado por **Runa**, una nutria, que restaura ecosistemas tomando decisiones con consecuencia visible.

| Nivel | Nombre | Tema |
| --- | --- | --- |
| 1 | El río en peligro | Ahorro y descontaminación del agua (ODS 6) |
| 2 | El humedal olvidado | Hábitat de la fauna acuática |
| 3 | El bosque silencioso | Fauna silvestre amenazada (ODS 15) |
| 4 | La escuela sostenible | Consumo de energía y agua |
| 5 | El Refugio de la Vida | Escena final (requiere las 4 insignias) |

Más detalle en [`docs/GDD.md`](docs/GDD.md).

## Tecnologías

- **Motor:** Unity 6 LTS (2D) con C#
- **Base de datos local:** SQLite 3
- **Configuración editable:** archivos JSON (`Assets/_Project/Data/Config/`)
- **Gráficos:** LibreSprite (pixel art) · **Audio:** Audacity + efectos libres
- **Control de versiones:** Git + GitHub (gestión con GitHub Projects, metodología Scrum)

## Estructura del repositorio

```
EcoGuardianes/
├── Assets/_Project/
│   ├── Scripts/
│   │   ├── Core/            # reglas del juego, ciclo entrada–proceso–salida–retroalimentación
│   │   ├── DataStructures/  # lista, pila, cola, grafo, tabla hash, ordenamiento (RF-EST)
│   │   ├── Levels/          # un módulo por nivel
│   │   ├── Math/            # gradiente, integral doble, campo vectorial (RF-MAT)
│   │   ├── Physics/         # energía y consumo de agua (RF-FIS)
│   │   ├── Persistence/     # SQLite y perfiles
│   │   └── UI/              # menú, HUD, recompensa, panel docente
│   ├── Data/Config/         # JSON: electrodomésticos, especies, tarjetas, ajustes
│   ├── Art/  Audio/  Scenes/  Prefabs/
│   └── Tests/EditMode/      # pruebas unitarias
├── docs/                    # requerimientos, GDD, arquitectura, diagramas, prototipos
├── .github/                 # plantillas de issues y pull requests
└── README.md
```

## Cómo abrir el proyecto

1. Instala **Unity Hub** y el editor **Unity 6 LTS** (con módulo *Windows Build Support*).
2. Clona el repositorio:
   ```bash
   git clone https://github.com/<usuario>/EcoGuardianes.git
   ```
3. En Unity Hub: **Add → Add project from disk** y selecciona la carpeta clonada.
4. La primera vez, Unity creará la carpeta `Library/` (puede tardar varios minutos; no se sube a Git).

> El repositorio todavía **no contiene `ProjectSettings/` ni `Packages/`**, porque se generan al crear el proyecto en Unity. Mira la sección *Primer commit con Unity* en [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Cómo generar el juego (build para Windows)

1. Abre el proyecto en Unity.
2. Menú **File → Build Profiles** (en versiones anteriores: *File → Build Settings*).
3. Selecciona la plataforma **Windows**, agrega las escenas a la lista y pulsa **Build**.
4. Elige una carpeta **fuera** del repositorio (o dentro de `Builds/`, que está ignorada por Git).
5. Comprime la carpeta resultante en `.zip` para distribuirla.

Requisito del proyecto (RNF-06): Windows 10 o superior, máximo 500 MB.

## Documentación

- [Requerimientos funcionales y no funcionales](docs/REQUERIMIENTOS.md)
- [Documento de diseño del videojuego (GDD)](docs/GDD.md)
- [Arquitectura y modelo de datos](docs/ARQUITECTURA.md)
- [Diagramas y prototipos](docs/diagramas/README.md)

## Equipo

- Santiago Pérez Bastidas
- Nicholas Alberto Siavichay Ocampo
- Samuel Felipe Arias Flechas
- Alejandra Becerra Peña
- Samuel Antonio Rojas Moncada

## Licencia

Código bajo licencia MIT (ver [`LICENSE`](LICENSE)). Los recursos de arte y audio deben ser propios o tener licencia que permita su uso (Ley 23 de 1982 y Ley 1915 de 2018); registra la procedencia en `Assets/_Project/Art/CREDITS.md` y `Assets/_Project/Audio/CREDITS.md`.
