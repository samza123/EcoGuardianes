# Changelog

Formato basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/).

## [Sin publicar]

### Añadido
- Estructura inicial del repositorio.
- Documentación del Incremento 1: requerimientos, GDD y arquitectura.
- Implementación base (sin integrar a Unity) de estructuras de datos propias: lista dinámica, pila, cola, grafo de niveles, tabla hash y MergeSort.
- Módulos de cálculo: gradiente numérico, suma de Riemann, energía eléctrica y volumen de agua.
- Archivos de configuración JSON de ejemplo (electrodomésticos, especies, tarjetas, ajustes).
- Pruebas unitarias EditMode iniciales.
