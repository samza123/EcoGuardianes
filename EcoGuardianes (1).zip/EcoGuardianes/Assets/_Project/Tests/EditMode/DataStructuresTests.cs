using System;
using System.Collections.Generic;
using EcoGuardianes.DataStructures;
using NUnit.Framework;

namespace EcoGuardianes.Tests
{
    public class DataStructuresTests
    {
        [TestCase(0)]
        [TestCase(1)]
        [TestCase(100)]
        public void DynamicList_AddAndRead_WorksWithNElements(int n)
        {
            var list = new DynamicList<int>();
            for (int i = 0; i < n; i++) list.Add(i);

            Assert.AreEqual(n, list.Count);
            for (int i = 0; i < n; i++) Assert.AreEqual(i, list[i]);
        }

        [Test]
        public void DynamicList_RemoveAt_ShiftsElements()
        {
            var list = new DynamicList<string>();
            list.Add("a"); list.Add("b"); list.Add("c");
            list.RemoveAt(1);

            Assert.AreEqual(2, list.Count);
            Assert.AreEqual("c", list[1]);
        }

        [Test]
        public void LinkedStack_IsLifo_AndThrowsWhenEmpty()
        {
            var stack = new LinkedStack<int>();
            stack.Push(1); stack.Push(2);

            Assert.AreEqual(2, stack.Pop());
            Assert.AreEqual(1, stack.Pop());
            Assert.Throws<InvalidOperationException>(() => stack.Pop());
        }

        [Test]
        public void CircularQueue_IsFifo_AndReinsertsFailedChallenges()
        {
            var queue = new CircularQueue<int>(2);
            for (int i = 1; i <= 5; i++) queue.Enqueue(i);

            int failed = queue.Dequeue();   // 1
            queue.Enqueue(failed);          // el reto fallado vuelve al final

            var order = new List<int>();
            while (!queue.IsEmpty) order.Add(queue.Dequeue());

            CollectionAssert.AreEqual(new[] { 2, 3, 4, 5, 1 }, order);
        }

        [Test]
        public void LevelGraph_FinalLevelLockedUntilFourBadges()
        {
            var graph = new LevelGraph();
            for (int level = 1; level <= 4; level++) graph.AddRequirement(level, 5);

            var completed = new HashSet<int> { 1, 2, 3 };
            Assert.IsFalse(graph.IsUnlocked(5, completed));

            completed.Add(4);
            Assert.IsTrue(graph.IsUnlocked(5, completed));
        }

        [Test]
        public void MergeSorter_SortsDescending_ForSortedReversedAndRepeated()
        {
            Comparison<int> descending = (a, b) => b.CompareTo(a);

            CollectionAssert.AreEqual(new[] { 3, 2, 1 }, MergeSorter.Sort(new[] { 3, 2, 1 }, descending));
            CollectionAssert.AreEqual(new[] { 3, 2, 1 }, MergeSorter.Sort(new[] { 1, 2, 3 }, descending));
            CollectionAssert.AreEqual(new[] { 5, 5, 2, 2 }, MergeSorter.Sort(new[] { 2, 5, 2, 5 }, descending));
        }

        [Test]
        public void HashTable_PutAndGet_ByIdentifier()
        {
            var table = new HashTable<string, int>();
            for (int i = 0; i < 1000; i++) table.Put("id" + i, i);

            Assert.AreEqual(1000, table.Count);
            Assert.IsTrue(table.TryGet("id999", out int value));
            Assert.AreEqual(999, value);
        }
    }
}
