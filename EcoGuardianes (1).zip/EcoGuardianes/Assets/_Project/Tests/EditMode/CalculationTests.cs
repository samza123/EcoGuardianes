using EcoGuardianes.Calculo;
using EcoGuardianes.Fisica;
using NUnit.Framework;

namespace EcoGuardianes.Tests
{
    public class CalculationTests
    {
        [Test]
        public void Energy_Iron1000W_2h_Is2Kwh()
        {
            Assert.AreEqual(2.00, EnergyCalculator.EnergyKwh(1000, 2), 0.001);
        }

        [Test]
        public void Monthly_1000W_2hPerDay_30Days_Is60Kwh()
        {
            Assert.AreEqual(60.0, EnergyCalculator.MonthlyKwh(1000, 2, 30), 0.001);
        }

        [Test]
        public void Water_10LPerMin_5Min_Is50L()
        {
            Assert.AreEqual(50.0, EnergyCalculator.WaterVolumeLiters(10, 5), 0.001);
        }

        [Test]
        public void KwhToJoules_UsesFactor3_6e6()
        {
            Assert.AreEqual(3.6e6, EnergyCalculator.KwhToJoules(1), 1e-6);
        }

        [Test]
        public void Gradient_OfPlane_MatchesAnalytic()
        {
            // C(x, y) = 3x + 2y  →  ∇C = (3, 2)
            var g = PollutionMath.Gradient((x, y) => 3 * x + 2 * y, 1.0, 1.0);
            Assert.AreEqual(3.0, g.dx, 0.01);
            Assert.AreEqual(2.0, g.dy, 0.01);
        }

        [Test]
        public void DoubleIntegral_OfXY_On0to2_MatchesAnalytic()
        {
            // ∬ x·y dA sobre [0,2]×[0,2] = 4
            double result = PollutionMath.DoubleIntegral((x, y) => x * y, 0, 2, 0, 2);
            Assert.AreEqual(4.0, result, 0.04); // error relativo ≤ 1 %
        }
    }
}
