using System;

namespace EcoGuardianes.Fisica
{
    /// <summary>
    /// Cálculos de Física 2 para el nivel 4 "La escuela sostenible" (RF-FIS-01 a RF-FIS-06).
    /// Siempre trabajar con unidades explícitas: W, kW, J, kWh, L/min, L.
    /// </summary>
    public static class EnergyCalculator
    {
        public const double JoulesPerKwh = 3.6e6;

        /// <summary>Energía en kWh: E = P × t, con P en vatios y t en horas.</summary>
        public static double EnergyKwh(double powerWatts, double hours)
        {
            if (powerWatts < 0 || hours < 0) throw new ArgumentOutOfRangeException(nameof(powerWatts), "Los valores no pueden ser negativos.");
            return powerWatts * hours / 1000.0;
        }

        /// <summary>Consumo mensual en kWh a partir del consumo diario.</summary>
        public static double MonthlyKwh(double powerWatts, double hoursPerDay, int days = 30)
        {
            return EnergyKwh(powerWatts, hoursPerDay) * days;
        }

        /// <summary>Costo aproximado = kWh × tarifa por kWh (tarifa configurable en ajustes.json).</summary>
        public static double Cost(double kwh, double tariffPerKwh)
        {
            return kwh * tariffPerKwh;
        }

        public static double KwhToJoules(double kwh)
        {
            return kwh * JoulesPerKwh;
        }

        public static double JoulesToKwh(double joules)
        {
            return joules / JoulesPerKwh;
        }

        /// <summary>
        /// Diferencia entre dos consumos (kWh) y porcentaje de ahorro respecto al mayor.
        /// Decisión de diseño por confirmar: el requerimiento RF-FIS-03 no especifica la base del porcentaje.
        /// </summary>
        public static (double differenceKwh, double percentOfHigher) Compare(double kwhA, double kwhB)
        {
            double high = Math.Max(kwhA, kwhB);
            double low = Math.Min(kwhA, kwhB);
            double difference = high - low;
            double percent = high > 0 ? difference / high * 100.0 : 0.0;
            return (difference, percent);
        }

        /// <summary>Volumen de agua en litros: V = Q × t, con Q en L/min y t en minutos (RF-FIS-06).</summary>
        public static double WaterVolumeLiters(double flowLitersPerMinute, double minutes)
        {
            if (flowLitersPerMinute < 0 || minutes < 0) throw new ArgumentOutOfRangeException(nameof(flowLitersPerMinute), "Los valores no pueden ser negativos.");
            return flowLitersPerMinute * minutes;
        }
    }
}
