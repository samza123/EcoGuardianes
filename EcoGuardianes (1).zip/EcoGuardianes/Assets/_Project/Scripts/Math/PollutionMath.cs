using System;

namespace EcoGuardianes.Calculo
{
    /// <summary>
    /// Cálculos de Matemáticas 3 para los niveles 1 y 2 (RF-MAT-02, RF-MAT-03).
    /// La concentración de contaminante se modela como una función C(x, y).
    /// </summary>
    public static class PollutionMath
    {
        /// <summary>
        /// Gradiente numérico (derivadas parciales por diferencias centrales).
        /// Apunta hacia donde la concentración aumenta más rápido: dirección de la fuente.
        /// </summary>
        public static (double dx, double dy) Gradient(Func<double, double, double> c, double x, double y, double h = 1e-5)
        {
            if (c == null) throw new ArgumentNullException(nameof(c));
            double dx = (c(x + h, y) - c(x - h, y)) / (2 * h);
            double dy = (c(x, y + h) - c(x, y - h)) / (2 * h);
            return (dx, dy);
        }

        /// <summary>
        /// Integral doble numérica de C sobre [x0, x1] × [y0, y1] con suma de Riemann (punto medio).
        /// Representa la cantidad total de contaminante en la región.
        /// </summary>
        public static double DoubleIntegral(Func<double, double, double> c,
                                            double x0, double x1, double y0, double y1,
                                            int cellsX = 100, int cellsY = 100)
        {
            if (c == null) throw new ArgumentNullException(nameof(c));
            if (cellsX <= 0 || cellsY <= 0) throw new ArgumentOutOfRangeException(nameof(cellsX), "Las celdas deben ser > 0.");

            double dx = (x1 - x0) / cellsX;
            double dy = (y1 - y0) / cellsY;
            double sum = 0.0;

            for (int i = 0; i < cellsX; i++)
            {
                double x = x0 + (i + 0.5) * dx;
                for (int j = 0; j < cellsY; j++)
                {
                    double y = y0 + (j + 0.5) * dy;
                    sum += c(x, y);
                }
            }
            return sum * dx * dy;
        }

        /// <summary>Porcentaje de contaminante retirado entre la cantidad inicial y la actual.</summary>
        public static double PercentRemoved(double initialAmount, double currentAmount)
        {
            if (initialAmount <= 0) return 0.0;
            return (initialAmount - currentAmount) / initialAmount * 100.0;
        }
    }
}
