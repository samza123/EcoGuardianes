using System.Collections.Generic;

namespace EcoGuardianes.DataStructures
{
    /// <summary>
    /// Tabla hash (diccionario) con identificador único, para insignias, especies y electrodomésticos (RF-EST-05).
    /// Encapsula Dictionary de .NET; si el curso exige una implementación propia, reemplazar el contenido
    /// manteniendo esta interfaz pública.
    /// Complejidad promedio: Put, Get y Remove en O(1).
    /// </summary>
    public class HashTable<TKey, TValue>
    {
        private readonly Dictionary<TKey, TValue> _table = new Dictionary<TKey, TValue>();

        public int Count => _table.Count;

        public void Put(TKey key, TValue value)
        {
            _table[key] = value;
        }

        public bool TryGet(TKey key, out TValue value)
        {
            return _table.TryGetValue(key, out value);
        }

        public bool Remove(TKey key)
        {
            return _table.Remove(key);
        }

        public bool ContainsKey(TKey key)
        {
            return _table.ContainsKey(key);
        }
    }
}
