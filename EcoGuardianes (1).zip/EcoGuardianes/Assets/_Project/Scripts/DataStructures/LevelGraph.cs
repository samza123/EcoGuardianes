using System;
using System.Collections.Generic;

namespace EcoGuardianes.DataStructures
{
    /// <summary>
    /// Grafo dirigido del mapa de niveles (RF-EST-04, RNF-12).
    /// Cada nodo es un nivel; una arista A → B significa "completar A es requisito para desbloquear B".
    /// El nivel final tendría aristas desde los 4 niveles previos, de modo que solo se desbloquea con las 4 insignias.
    /// Complejidad: AddLevel y AddRequirement O(1); IsUnlocked O(grado de entrada).
    /// </summary>
    public class LevelGraph
    {
        // Para cada nivel, la lista de niveles que deben completarse antes.
        private readonly Dictionary<int, List<int>> _prerequisites = new Dictionary<int, List<int>>();

        public void AddLevel(int levelId)
        {
            if (!_prerequisites.ContainsKey(levelId))
            {
                _prerequisites[levelId] = new List<int>();
            }
        }

        /// <summary>Declara que <paramref name="requiredLevel"/> debe completarse para desbloquear <paramref name="unlockedLevel"/>.</summary>
        public void AddRequirement(int requiredLevel, int unlockedLevel)
        {
            AddLevel(requiredLevel);
            AddLevel(unlockedLevel);
            if (!_prerequisites[unlockedLevel].Contains(requiredLevel))
            {
                _prerequisites[unlockedLevel].Add(requiredLevel);
            }
        }

        /// <summary>Un nivel está desbloqueado si todos sus requisitos están en el conjunto de niveles completados.</summary>
        public bool IsUnlocked(int levelId, ISet<int> completedLevels)
        {
            if (completedLevels == null) throw new ArgumentNullException(nameof(completedLevels));
            if (!_prerequisites.TryGetValue(levelId, out List<int> required))
            {
                throw new ArgumentException("El nivel no existe en el grafo.", nameof(levelId));
            }
            foreach (int requiredLevel in required)
            {
                if (!completedLevels.Contains(requiredLevel)) return false;
            }
            return true;
        }
    }
}
