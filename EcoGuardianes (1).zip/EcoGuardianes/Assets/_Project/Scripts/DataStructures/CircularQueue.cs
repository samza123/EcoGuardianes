using System;

namespace EcoGuardianes.DataStructures
{
    /// <summary>
    /// Cola (FIFO) circular con crecimiento dinámico, usada para los retos pendientes (RF-EST-03).
    /// Los retos fallados se reinsertan con Enqueue.
    /// Complejidad: Enqueue O(1) amortizado, Dequeue y Peek O(1).
    /// </summary>
    public class CircularQueue<T>
    {
        private T[] _items;
        private int _head;
        private int _count;

        public CircularQueue(int initialCapacity = 4)
        {
            _items = new T[Math.Max(1, initialCapacity)];
        }

        public int Count => _count;

        public bool IsEmpty => _count == 0;

        public void Enqueue(T item)
        {
            if (_count == _items.Length) Grow();
            _items[(_head + _count) % _items.Length] = item;
            _count++;
        }

        public T Dequeue()
        {
            if (_count == 0) throw new InvalidOperationException("La cola está vacía.");
            T item = _items[_head];
            _items[_head] = default(T);
            _head = (_head + 1) % _items.Length;
            _count--;
            return item;
        }

        public T Peek()
        {
            if (_count == 0) throw new InvalidOperationException("La cola está vacía.");
            return _items[_head];
        }

        private void Grow()
        {
            var bigger = new T[_items.Length * 2];
            for (int i = 0; i < _count; i++)
            {
                bigger[i] = _items[(_head + i) % _items.Length];
            }
            _items = bigger;
            _head = 0;
        }
    }
}
