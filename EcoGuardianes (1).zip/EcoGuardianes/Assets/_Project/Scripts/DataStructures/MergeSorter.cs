using System;
using System.Collections.Generic;

namespace EcoGuardianes.DataStructures
{
    /// <summary>
    /// Ordenamiento MergeSort estable implementado en el proyecto (RF-EST-06),
    /// usado para ordenar electrodomésticos por consumo.
    /// Complejidad: O(n log n) en tiempo, O(n) en memoria auxiliar.
    /// No modifica la colección original: devuelve un arreglo nuevo.
    /// </summary>
    public static class MergeSorter
    {
        public static T[] Sort<T>(IReadOnlyList<T> source, Comparison<T> comparison)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (comparison == null) throw new ArgumentNullException(nameof(comparison));

            var items = new T[source.Count];
            for (int i = 0; i < items.Length; i++)
            {
                items[i] = source[i];
            }

            var buffer = new T[items.Length];
            SortRange(items, buffer, 0, items.Length - 1, comparison);
            return items;
        }

        private static void SortRange<T>(T[] items, T[] buffer, int low, int high, Comparison<T> comparison)
        {
            if (low >= high) return;

            int mid = low + (high - low) / 2;
            SortRange(items, buffer, low, mid, comparison);
            SortRange(items, buffer, mid + 1, high, comparison);

            int left = low;
            int right = mid + 1;
            int k = low;

            while (left <= mid && right <= high)
            {
                buffer[k++] = comparison(items[left], items[right]) <= 0 ? items[left++] : items[right++];
            }
            while (left <= mid) buffer[k++] = items[left++];
            while (right <= high) buffer[k++] = items[right++];

            for (k = low; k <= high; k++)
            {
                items[k] = buffer[k];
            }
        }
    }
}
