using System;

namespace EcoGuardianes.DataStructures
{
    /// <summary>
    /// Pila (LIFO) con nodos enlazados, usada para el historial de decisiones (RF-EST-02).
    /// Complejidad: Push, Pop y Peek en O(1).
    /// </summary>
    public class LinkedStack<T>
    {
        private class Node
        {
            public T Value;
            public Node Next;
        }

        private Node _top;

        public int Count { get; private set; }

        public bool IsEmpty => Count == 0;

        public void Push(T value)
        {
            _top = new Node { Value = value, Next = _top };
            Count++;
        }

        public T Pop()
        {
            if (_top == null) throw new InvalidOperationException("La pila está vacía.");
            T value = _top.Value;
            _top = _top.Next;
            Count--;
            return value;
        }

        public T Peek()
        {
            if (_top == null) throw new InvalidOperationException("La pila está vacía.");
            return _top.Value;
        }
    }
}
