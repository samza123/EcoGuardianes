using System;

namespace EcoGuardianes.DataStructures
{
    /// <summary>
    /// Lista dinámica basada en arreglo que duplica su capacidad al llenarse (RF-EST-01).
    /// Complejidad: Add O(1) amortizado, acceso por índice O(1), RemoveAt O(n).
    /// </summary>
    public class DynamicList<T>
    {
        private T[] _items;
        private int _count;

        public DynamicList(int initialCapacity = 4)
        {
            _items = new T[Math.Max(1, initialCapacity)];
        }

        public int Count => _count;

        public T this[int index]
        {
            get
            {
                CheckIndex(index);
                return _items[index];
            }
        }

        /// <summary>Agrega un elemento al final.</summary>
        public void Add(T item)
        {
            if (_count == _items.Length)
            {
                Array.Resize(ref _items, _items.Length * 2);
            }
            _items[_count++] = item;
        }

        /// <summary>Elimina el elemento en la posición indicada y desplaza los siguientes.</summary>
        public void RemoveAt(int index)
        {
            CheckIndex(index);
            for (int i = index; i < _count - 1; i++)
            {
                _items[i] = _items[i + 1];
            }
            _items[--_count] = default(T);
        }

        /// <summary>Devuelve el índice de la primera coincidencia o -1 si no existe.</summary>
        public int IndexOf(T item)
        {
            var comparer = System.Collections.Generic.EqualityComparer<T>.Default;
            for (int i = 0; i < _count; i++)
            {
                if (comparer.Equals(_items[i], item)) return i;
            }
            return -1;
        }

        public void Clear()
        {
            Array.Clear(_items, 0, _count);
            _count = 0;
        }

        private void CheckIndex(int index)
        {
            if (index < 0 || index >= _count)
            {
                throw new ArgumentOutOfRangeException(nameof(index));
            }
        }
    }
}
