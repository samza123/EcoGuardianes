# Créditos de audio

Registra aquí la procedencia y licencia de cada música, efecto o voz.

| Archivo | Autor / fuente | Licencia | Enlace |
| --- | --- | --- | --- |
| (ejemplo) voz_runa_muybien.wav | Equipo EcoGuardianes | Propio | — |
