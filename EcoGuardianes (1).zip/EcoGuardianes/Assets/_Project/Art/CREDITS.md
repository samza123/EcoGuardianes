# Créditos de arte

Registra aquí la procedencia y licencia de cada recurso gráfico (obligatorio: Ley 23 de 1982 y Ley 1915 de 2018).

| Archivo | Autor / fuente | Licencia | Enlace |
| --- | --- | --- | --- |
| (ejemplo) runa_idle.png | Equipo EcoGuardianes | Propio | — |
