## Qué cambia
<!-- Resumen corto -->

## Requerimientos relacionados
<!-- Ej.: RF-EST-02, RNF-12 -->

## Verificación
- [ ] Probé el criterio de verificación del requerimiento
- [ ] Las pruebas EditMode pasan (Window → General → Test Runner)
- [ ] Textos y valores nuevos están en `Data/Config/`, no en el código
- [ ] Incluí los archivos `.meta` de los assets nuevos
- [ ] Sin violencia, publicidad, chat ni enlaces externos (RNF-09, RNF-14)

## Capturas (si afecta la interfaz)
