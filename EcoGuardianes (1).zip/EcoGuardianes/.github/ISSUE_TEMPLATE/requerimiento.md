---
name: Requerimiento / tarea
about: Implementar un requerimiento del backlog
title: "[RF-XXX-00] "
labels: requerimiento
---

## Requerimiento
ID: RF-XXX-00
Prioridad: Alta / Media / Baja
Objetivo específico relacionado: OE-

## Descripción
<!-- Qué debe hacer el sistema -->

## Criterio de verificación
<!-- Copiado de docs/REQUERIMIENTOS.md -->

## Definition of Done
- [ ] Cumple el criterio de verificación
- [ ] Revisión cruzada aprobada
- [ ] Trazabilidad con su objetivo
- [ ] Documentación actualizada si aplica
