---
name: Error (bug)
about: Reportar un fallo del juego
title: "[BUG] "
labels: bug
---

## ¿Qué pasó?

## Pasos para reproducirlo
1.
2.
3.

## Resultado esperado

## Entorno
- Versión de Unity:
- Sistema operativo:
- Nivel donde ocurre:

## Capturas o registro (Console)
